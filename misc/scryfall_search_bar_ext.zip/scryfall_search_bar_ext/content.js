document.getElementById("header-search-field").focus();
document.getElementById("header-search-field").select();